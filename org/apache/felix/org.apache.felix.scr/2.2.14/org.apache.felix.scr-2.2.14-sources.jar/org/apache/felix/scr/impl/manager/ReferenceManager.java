/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.felix.scr.impl.manager;

import java.util.List;

import org.osgi.framework.ServiceReference;

public interface ReferenceManager<S, T> {

	/**
	 * Returns an array of <code>ServiceReference</code> instances of all
	 * services this instance is bound to or <code>null</code> if no services
	 * are actually bound.
	 */
	List<ServiceReference<?>> getServiceReferences();

	/**
	 * Returns the name of the service reference.
	 */
	String getName();

	/**
	 * Returns the target filter of this dependency as a string or
	 * <code>null</code> if this dependency has no target filter set.
	 *
	 * @return The target filter of this dependency or <code>null</code> if
	 *      none is set.
	 */
	String getTarget();

    boolean isSatisfied();
}