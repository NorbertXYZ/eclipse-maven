/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.sshd.common.util;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Proxy;

/**
 * @author <a href="mailto:dev@mina.apache.org">Apache MINA SSHD Project</a>
 */
public final class ProxyUtils {
    private ProxyUtils() {
        throw new UnsupportedOperationException("No instance");
    }

    public static <T> T newProxyInstance(Class<T> type, InvocationHandler handler) {
        return newProxyInstance(type.getClassLoader(), type, handler);
    }

    public static <T> T newProxyInstance(ClassLoader cl, Class<T> type, InvocationHandler handler) {
        Class<?>[] interfaces = { type };
        Object wrapper = Proxy.newProxyInstance(cl, interfaces, handler);
        return type.cast(wrapper);
    }

    public static Throwable unwrapInvocationThrowable(Throwable t) {
        if (t instanceof InvocationTargetException) {
            return unwrapInvocationThrowable(((InvocationTargetException) t).getTargetException());
        } else {
            return t;
        }
    }
}
