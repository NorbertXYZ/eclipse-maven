/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.sshd.common.util.io.resource;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Path;

import org.apache.sshd.common.util.io.IoUtils;

/**
 * @author <a href="mailto:dev@mina.apache.org">Apache MINA SSHD Project</a>
 */
public class PathResource extends AbstractIoResource<Path> {
    private final OpenOption[] openOptions;

    public PathResource(Path path) {
        super(Path.class, path);
        this.openOptions = IoUtils.EMPTY_OPEN_OPTIONS;
    }

    public PathResource(Path path, OpenOption... openOptions) {
        super(Path.class, path);
        // Use a clone to avoid shared instance modification
        this.openOptions = (openOptions == null) ? IoUtils.EMPTY_OPEN_OPTIONS : openOptions.clone();
    }

    public Path getPath() {
        return getResourceValue();
    }

    public OpenOption[] getOpenOptions() {
        // Use a clone to avoid shared instance modification
        return (openOptions.length <= 0) ? openOptions : openOptions.clone();
    }

    @Override
    public InputStream openInputStream() throws IOException {
        return Files.newInputStream(getPath(), getOpenOptions());
    }
}
