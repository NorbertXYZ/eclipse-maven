//
// ========================================================================
// Copyright (c) 1995 Mort Bay Consulting Pty Ltd and others.
//
// This program and the accompanying materials are made available under the
// terms of the Eclipse Public License v. 2.0 which is available at
// https://www.eclipse.org/legal/epl-2.0, or the Apache License, Version 2.0
// which is available at https://www.apache.org/licenses/LICENSE-2.0.
//
// SPDX-License-Identifier: EPL-2.0 OR Apache-2.0
// ========================================================================
//

package org.eclipse.jetty.io;

import java.nio.ByteBuffer;

/**
 * <p>Abstract implementation of {@link RetainableByteBuffer} with
 * reference counting.</p>
 * @deprecated
 */
@Deprecated(forRemoval = true)
public abstract class AbstractRetainableByteBuffer extends RetainableByteBuffer.FixedCapacity
{
    private final ReferenceCounter _refCount;

    public AbstractRetainableByteBuffer(ByteBuffer byteBuffer)
    {
        super(byteBuffer, new ReferenceCounter(0));
        _refCount = (ReferenceCounter)getWrapped();
    }

    /**
     * @see ReferenceCounter#acquire()
     */
    protected void acquire()
    {
        _refCount.acquire();
    }
}
