module org.eclipse.jetty.ee8.apache.jsp {
    requires java.xml;
    requires transitive jetty.servlet.api;
    requires org.eclipse.jetty.util;
    requires transitive org.mortbay.apache.jasper;
    requires org.slf4j;
    exports org.eclipse.jetty.ee8.apache.jsp;
    exports org.eclipse.jetty.ee8.jsp;
    provides org.apache.juli.logging.Log with org.eclipse.jetty.ee8.apache.jsp.JuliLog;
    provides javax.servlet.ServletContainerInitializer with org.eclipse.jetty.ee8.apache.jsp.JettyJasperInitializer;
}
