module org.eclipse.jetty.ee8.servlet {
    requires org.slf4j;
    requires transitive org.eclipse.jetty.ee8.nested;
    requires transitive org.eclipse.jetty.ee8.security;
    requires static java.desktop;
    requires static java.management;
    requires static org.eclipse.jetty.jmx;
    requires static org.eclipse.jetty.util.ajax;
    exports org.eclipse.jetty.ee8.servlet;
    exports org.eclipse.jetty.ee8.servlet.listener;
    exports org.eclipse.jetty.ee8.servlet.jmx to org.eclipse.jetty.jmx;
}
