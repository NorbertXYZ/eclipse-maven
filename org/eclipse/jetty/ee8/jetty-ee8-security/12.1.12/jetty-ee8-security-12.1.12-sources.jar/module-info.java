//
// ========================================================================
// Copyright (c) 1995 Mort Bay Consulting Pty Ltd and others.
//
// This program and the accompanying materials are made available under the
// terms of the Eclipse Public License v. 2.0 which is available at
// https://www.eclipse.org/legal/epl-2.0, or the Apache License, Version 2.0
// which is available at https://www.apache.org/licenses/LICENSE-2.0.
//
// SPDX-License-Identifier: EPL-2.0 OR Apache-2.0
// ========================================================================
//
import org.eclipse.jetty.ee8.security.Authenticator;

module org.eclipse.jetty.ee8.security {
    requires org.slf4j;
    requires transitive org.eclipse.jetty.server;
    requires transitive org.eclipse.jetty.ee8.nested;
    requires static java.security.jgss;
    requires static java.sql;
    exports org.eclipse.jetty.ee8.security;
    exports org.eclipse.jetty.ee8.security.authentication;
    uses Authenticator.Factory;
}
