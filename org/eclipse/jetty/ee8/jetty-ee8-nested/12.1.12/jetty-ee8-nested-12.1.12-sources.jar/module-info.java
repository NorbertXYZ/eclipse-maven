module org.eclipse.jetty.ee8.nested {
    requires transitive jetty.servlet.api;
    requires transitive org.eclipse.jetty.security;
    requires transitive org.eclipse.jetty.http;
    requires transitive org.eclipse.jetty.server;
    requires transitive org.eclipse.jetty.session;
    requires transitive org.slf4j;
    requires static org.eclipse.jetty.jmx;
    exports org.eclipse.jetty.ee8.nested;
    exports org.eclipse.jetty.ee8.nested.jmx to org.eclipse.jetty.jmx;
}
