/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.tomcat.util.descriptor.web;


/**
 * <p>
 * Representation of a message destination reference for a web application, as represented in a
 * <code>&lt;message-destination-ref&gt;</code> element in the deployment descriptor.
 * </p>
 *
 * @since Tomcat 5.0
 */
public class MessageDestinationRef extends ResourceBase {

    private static final long serialVersionUID = 1L;

    /**
     * Default constructor.
     */
    public MessageDestinationRef() {
    }

    // ------------------------------------------------------------- Properties


    /**
     * The link of this destination ref.
     */
    private String link = null;

    /**
     * Get the link.
     * @return the link
     */
    public String getLink() {
        return this.link;
    }

    /**
     * Set the link.
     * @param link the link
     */
    public void setLink(String link) {
        this.link = link;
    }


    /**
     * The usage of this destination ref.
     */
    private String usage = null;

    /**
     * Get the usage.
     * @return the usage
     */
    public String getUsage() {
        return this.usage;
    }

    /**
     * Set the usage.
     * @param usage the usage
     */
    public void setUsage(String usage) {
        this.usage = usage;
    }

    // --------------------------------------------------------- Public Methods


    /**
     * Return a String representation of this object.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("MessageDestinationRef[");
        sb.append("name=");
        sb.append(getName());
        if (link != null) {
            sb.append(", link=");
            sb.append(link);
        }
        if (getType() != null) {
            sb.append(", type=");
            sb.append(getType());
        }
        if (usage != null) {
            sb.append(", usage=");
            sb.append(usage);
        }
        if (getDescription() != null) {
            sb.append(", description=");
            sb.append(getDescription());
        }
        sb.append(']');
        return sb.toString();
    }


    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((link == null) ? 0 : link.hashCode());
        result = prime * result + ((usage == null) ? 0 : usage.hashCode());
        return result;
    }


    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!super.equals(obj)) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        MessageDestinationRef other = (MessageDestinationRef) obj;
        if (link == null) {
            if (other.link != null) {
                return false;
            }
        } else if (!link.equals(other.link)) {
            return false;
        }
        if (usage == null) {
            return other.usage == null;
        } else {
            return usage.equals(other.usage);
        }
    }
}
