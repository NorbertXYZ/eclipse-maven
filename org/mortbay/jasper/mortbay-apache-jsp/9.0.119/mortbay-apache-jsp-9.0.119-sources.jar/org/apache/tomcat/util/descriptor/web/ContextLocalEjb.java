/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.tomcat.util.descriptor.web;


/**
 * Representation of a local EJB resource reference for a web application, as represented in a
 * <code>&lt;ejb-local-ref&gt;</code> element in the deployment descriptor.
 */
public class ContextLocalEjb extends ResourceBase {

    private static final long serialVersionUID = 1L;

    /**
     * Default constructor for ContextLocalEjb.
     */
    public ContextLocalEjb() {
    }

    // ------------------------------------------------------------- Properties

    /**
     * The name of the EJB home implementation class.
     */
    private String home = null;

    /**
     * Returns the name of the EJB home implementation class.
     *
     * @return the EJB home class name
     */
    public String getHome() {
        return this.home;
    }

    /**
     * Sets the name of the EJB home implementation class.
     *
     * @param home the EJB home class name
     */
    public void setHome(String home) {
        this.home = home;
    }


    /**
     * The link to a J2EE EJB definition.
     */
    private String link = null;

    /**
     * Returns the link to a Jakarta EE EJB definition.
     *
     * @return the EJB link
     */
    public String getLink() {
        return this.link;
    }

    /**
     * Sets the link to a Jakarta EE EJB definition.
     *
     * @param link the EJB link
     */
    public void setLink(String link) {
        this.link = link;
    }


    /**
     * The name of the EJB local implementation class.
     */
    private String local = null;

    /**
     * Returns the name of the EJB local implementation class.
     *
     * @return the EJB local class name
     */
    public String getLocal() {
        return this.local;
    }

    /**
     * Sets the name of the EJB local implementation class.
     *
     * @param local the EJB local class name
     */
    public void setLocal(String local) {
        this.local = local;
    }


    // --------------------------------------------------------- Public Methods


    /**
     * Return a String representation of this object.
     */
    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder("ContextLocalEjb[");
        sb.append("name=");
        sb.append(getName());
        if (getDescription() != null) {
            sb.append(", description=");
            sb.append(getDescription());
        }
        if (getType() != null) {
            sb.append(", type=");
            sb.append(getType());
        }
        if (home != null) {
            sb.append(", home=");
            sb.append(home);
        }
        if (link != null) {
            sb.append(", link=");
            sb.append(link);
        }
        if (local != null) {
            sb.append(", local=");
            sb.append(local);
        }
        sb.append(']');
        return sb.toString();
    }


    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((home == null) ? 0 : home.hashCode());
        result = prime * result + ((link == null) ? 0 : link.hashCode());
        result = prime * result + ((local == null) ? 0 : local.hashCode());
        return result;
    }


    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!super.equals(obj)) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        ContextLocalEjb other = (ContextLocalEjb) obj;
        if (home == null) {
            if (other.home != null) {
                return false;
            }
        } else if (!home.equals(other.home)) {
            return false;
        }
        if (link == null) {
            if (other.link != null) {
                return false;
            }
        } else if (!link.equals(other.link)) {
            return false;
        }
        if (local == null) {
            return other.local == null;
        } else {
            return local.equals(other.local);
        }
    }
}
