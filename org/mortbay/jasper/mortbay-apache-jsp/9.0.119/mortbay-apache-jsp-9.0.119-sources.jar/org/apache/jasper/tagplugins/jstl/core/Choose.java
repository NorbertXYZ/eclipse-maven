/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.jasper.tagplugins.jstl.core;

import org.apache.jasper.compiler.tagplugin.TagPlugin;
import org.apache.jasper.compiler.tagplugin.TagPluginContext;

/**
 * Tag plugin for the JSTL &lt;c:choose&gt; tag.
 */
public final class Choose implements TagPlugin {

    /**
     * Creates a new Choose tag plugin.
     */
    public Choose() {
    }

    @Override
    public void doTag(TagPluginContext ctxt) {

        // Not much to do here, much of the work will be done in the
        // containing tags, <c:when> and <c:otherwise>.

        ctxt.generateBody();
        // See comments in When.java for the reason "}" is generated here.
        ctxt.generateJavaSource("}");
    }
}
