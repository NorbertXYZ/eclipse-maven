/*
 * Copyright (c) OSGi Alliance (2013, 2017). All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Metatype Annotations Package Version 1.4.
 * <p>
 * This package is not used at runtime. Annotated classes are processed by tools
 * to generate Meta Type Resources which are used at runtime.
 *
 * @author $Id: b6b51f1465c15b236ff746f0d758b02972f4ee71 $
 */

@Version(METATYPE_SPECIFICATION_VERSION)
package aQute.bnd.metatype.annotations;

import static aQute.bnd.metatype.annotations.MetaTypeConstants.METATYPE_SPECIFICATION_VERSION;

import org.osgi.annotation.versioning.Version;
