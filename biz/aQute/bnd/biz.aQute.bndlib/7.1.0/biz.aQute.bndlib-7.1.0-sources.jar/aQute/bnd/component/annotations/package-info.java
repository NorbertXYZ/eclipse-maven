/*******************************************************************************
 * Copyright (c) Contributors to the Eclipse Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0 
 *******************************************************************************/

/**
 * Service Component Annotations Package Version 1.5.
 * <p>
 * This package is not used at runtime. Annotated classes are processed by tools
 * to generate Component Descriptions which are used at runtime.
 *
 * @author $Id: 32f4103831d675bbb7bc14ce8150827a094c6178 $
 */

@Version(COMPONENT_SPECIFICATION_VERSION)
package aQute.bnd.component.annotations;

import static aQute.bnd.component.ComponentConstants.COMPONENT_SPECIFICATION_VERSION;

import org.osgi.annotation.versioning.Version;

