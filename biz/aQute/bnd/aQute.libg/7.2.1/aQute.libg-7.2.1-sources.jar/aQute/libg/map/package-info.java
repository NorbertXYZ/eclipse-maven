@org.osgi.annotation.versioning.Version("1.4.0")
package aQute.libg.map;
